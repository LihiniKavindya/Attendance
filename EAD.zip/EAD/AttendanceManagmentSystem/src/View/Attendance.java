/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Model.Dbconnection;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Lihini
 */
public class Attendance extends javax.swing.JFrame {

       String TeacherIDout;
    /**
     * Creates new form Attendance
     * 
     */
    public Attendance(String TeacherID) {
        initComponents();
        this.TeacherIDout=TeacherID;
        displayExistingStudentData();
        
    }
    
  // Call the method
   


private void displayExistingStudentData() {
    try {
        try (Connection connection = Dbconnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(getSql())) {

            preparedStatement.setString(1, TeacherIDout);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                DefaultTableModel tableModel = (DefaultTableModel) attendList.getModel();
                tableModel.setRowCount(0); // Clear existing data
              

                while (resultSet.next()) {
                    String studentID = resultSet.getString("StudentID");
                    String studentname = resultSet.getString("StudentName");
                      String teacherID = resultSet.getString("TeacherID");
                String classid = resultSet.getString("classid");
                 TidTxt.setText(teacherID);
                 cidTxt.setText(classid);
                
                    
                   
                    

                    if (studentID != null && studentname != null) {
                        // Add the fetched data as a new row in the table
                        tableModel.addRow(new Object[]{studentID, studentname});
                    }
                }
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }
}

private String getSql() {
    return "SELECT S.StudentID, S.StudentName ,T.TeacherID,T.classid\n" +
            "FROM Students S\n" +
            "JOIN Teacher T ON S.ClassID = T.ClassID\n" +
            "WHERE T.username = ?";
}


private void saveAttendance() {
    try {
           Connection connection = Dbconnection.getConnection();
        connection.setAutoCommit(false); // Disable auto-commit for transaction management

        // Insert attendance data into the AttendenceMain table
        String mainQuery = "INSERT INTO AttendenceMain (TeacherId, ClassId, aDate) VALUES (?, ?, ?)";
        try (PreparedStatement mainStatement = connection.prepareStatement(mainQuery, Statement.RETURN_GENERATED_KEYS)) {
            mainStatement.setString(1, TeacherIDout);
            mainStatement.setString(2, cidTxt.getText()); // Assuming classid is stored in the cidTxt field
            mainStatement.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            mainStatement.executeUpdate();

            // Get the generated AId
            ResultSet generatedKeys = mainStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int AId = generatedKeys.getInt(1);

                // Iterate through the table model to get attendance data
                DefaultTableModel attendanceTableModel = (DefaultTableModel) attendList.getModel();

                for (int i = 0; i < attendanceTableModel.getRowCount(); i++) {
                    String studentId = attendanceTableModel.getValueAt(i, 0).toString(); // Assuming student ID is a string
                    Object attendanceValue = attendanceTableModel.getValueAt(i, 2);

                    // Check if the value is not null before converting to boolean
                    boolean isPresent = attendanceValue != null && (boolean) attendanceValue;

                    // Convert boolean value to "present" or "absent"
                    String attendanceStatus = isPresent ? "present" : "absent";

                    // Insert attendance data into the AttendenceSub table
                    String subQuery = "INSERT INTO AttendenceSub (AId, StudentID, AttendenceCheck) VALUES (?, ?, ?)";
                    try (PreparedStatement subStatement = connection.prepareStatement(subQuery)) {
                        subStatement.setInt(1, AId);
                        subStatement.setString(2, studentId);
                        subStatement.setString(3, attendanceStatus);
                        subStatement.executeUpdate();
                    }
                }

                // Debugging: Print the executed queries
                System.out.println("Executing main query: " + mainStatement.toString());

                // Commit the transaction if everything is successful
                connection.commit();
                JOptionPane.showMessageDialog(this, "Attendance saved successfully");
            } else {
                // Handle the case where no AId was generated
                System.err.println("Failed to retrieve AId");
            }
        }

        connection.setAutoCommit(true); // Re-enable auto-commit
        connection.close();

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error saving attendance");
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        attendList = new javax.swing.JTable();
        markBtn = new javax.swing.JButton();
        TidTxt = new javax.swing.JTextField();
        cidTxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        tab111 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        tab222 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        tab333 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        LogoutBtn = new javax.swing.JButton();
        tab444 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();

        jScrollPane2.setViewportView(jTextPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(31, 122, 140));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("TeacherID ");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("Class ");

        attendList.setBackground(new java.awt.Color(204, 204, 204));
        attendList.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        attendList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "StudentID", "Name", "Attendance"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        attendList.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane1.setViewportView(attendList);
        if (attendList.getColumnModel().getColumnCount() > 0) {
            attendList.getColumnModel().getColumn(0).setResizable(false);
        }

        markBtn.setBackground(new java.awt.Color(31, 122, 140));
        markBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        markBtn.setForeground(new java.awt.Color(255, 255, 255));
        markBtn.setText("Mark");
        markBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        markBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                markBtnActionPerformed(evt);
            }
        });

        TidTxt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        cidTxt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 153));
        jLabel5.setText("STUDENT ATTENDANCE");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1006, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(markBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TidTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(148, 148, 148)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cidTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jLabel5)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TidTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9)
                    .addComponent(cidTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 472, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(markBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        jPanel1.setBackground(new java.awt.Color(191, 219, 247));

        tab111.setBackground(new java.awt.Color(31, 122, 140));
        tab111.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tab111.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab111MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tab111MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tab111MouseExited(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("TEACHER");

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/teacher.png"))); // NOI18N
        jLabel20.setText("jLabel20");

        javax.swing.GroupLayout tab111Layout = new javax.swing.GroupLayout(tab111);
        tab111.setLayout(tab111Layout);
        tab111Layout.setHorizontalGroup(
            tab111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab111Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(40, 40, 40))
        );
        tab111Layout.setVerticalGroup(
            tab111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab111Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(tab111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel20))
                .addContainerGap())
        );

        tab222.setBackground(new java.awt.Color(31, 122, 140));
        tab222.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tab222.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab222MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tab222MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tab222MouseExited(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("STUDENT");

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/student (1).png"))); // NOI18N
        jLabel18.setText("jLabel18");

        javax.swing.GroupLayout tab222Layout = new javax.swing.GroupLayout(tab222);
        tab222.setLayout(tab222Layout);
        tab222Layout.setHorizontalGroup(
            tab222Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab222Layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(40, 40, 40))
        );
        tab222Layout.setVerticalGroup(
            tab222Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab222Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tab222Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel18))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tab333.setBackground(new java.awt.Color(31, 122, 140));
        tab333.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tab333.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab333MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tab333MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tab333MouseExited(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ATTENDANCE");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/immigration.png"))); // NOI18N
        jLabel21.setText("jLabel21");

        javax.swing.GroupLayout tab333Layout = new javax.swing.GroupLayout(tab333);
        tab333.setLayout(tab333Layout);
        tab333Layout.setHorizontalGroup(
            tab333Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab333Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(23, 23, 23))
        );
        tab333Layout.setVerticalGroup(
            tab333Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab333Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(tab333Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel21))
                .addContainerGap())
        );

        LogoutBtn.setBackground(new java.awt.Color(191, 219, 247));
        LogoutBtn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LogoutBtn.setForeground(new java.awt.Color(102, 102, 102));
        LogoutBtn.setText("Log out");
        LogoutBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        LogoutBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        LogoutBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutBtnMouseClicked(evt);
            }
        });

        tab444.setBackground(new java.awt.Color(31, 122, 140));
        tab444.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tab444.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tab444MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tab444MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tab444MouseExited(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("REPORT");

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/report.png"))); // NOI18N
        jLabel22.setText("jLabel22");

        javax.swing.GroupLayout tab444Layout = new javax.swing.GroupLayout(tab444);
        tab444.setLayout(tab444Layout);
        tab444Layout.setHorizontalGroup(
            tab444Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab444Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addGap(53, 53, 53))
        );
        tab444Layout.setVerticalGroup(
            tab444Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tab444Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(tab444Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel22))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tab111, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tab222, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(tab333, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(LogoutBtn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(tab444, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(tab111, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tab222, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tab333, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tab444, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 291, Short.MAX_VALUE)
                .addComponent(LogoutBtn)
                .addGap(31, 31, 31))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tab111MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab111MouseEntered
       float[] hsbvals = new float[3];
      Color.RGBtoHSB(191,219,247,hsbvals);
      tab111.setBackground(Color.getHSBColor(hsbvals[0],hsbvals[1],hsbvals[2]));  
// TODO add your handling code here:
    }//GEN-LAST:event_tab111MouseEntered

    private void tab111MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab111MouseExited
       float[] hsbvals = new float[3];
      Color.RGBtoHSB(31,122,140,hsbvals);
      tab111.setBackground(Color.getHSBColor(hsbvals[0],hsbvals[1],hsbvals[2]));   
// TODO add your handling code here:
    }//GEN-LAST:event_tab111MouseExited

    private void tab222MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab222MouseEntered
       float[] hsbvals = new float[3];
      Color.RGBtoHSB(191,219,247,hsbvals);
      tab222.setBackground(Color.getHSBColor(hsbvals[0],hsbvals[1],hsbvals[2])); 
        // TODO add your handling code here:
    }//GEN-LAST:event_tab222MouseEntered

    private void tab222MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab222MouseExited
        float[] hsbvals = new float[3];
      Color.RGBtoHSB(31,122,140,hsbvals);
      tab222.setBackground(Color.getHSBColor(hsbvals[0],hsbvals[1],hsbvals[2]));   
        // TODO add your handling code here:
    }//GEN-LAST:event_tab222MouseExited

    private void tab333MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab333MouseEntered
      float[] hsbvals = new float[3];
      Color.RGBtoHSB(191,219,247,hsbvals);
      tab333.setBackground(Color.getHSBColor(hsbvals[0],hsbvals[1],hsbvals[2])); 
        // TODO add your handling code here:
    }//GEN-LAST:event_tab333MouseEntered

    private void tab333MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab333MouseExited
        float[] hsbvals = new float[3];
      Color.RGBtoHSB(31,122,140,hsbvals);
      tab333.setBackground(Color.getHSBColor(hsbvals[0],hsbvals[1],hsbvals[2]));   
        // TODO add your handling code here:
    }//GEN-LAST:event_tab333MouseExited

    private void tab444MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab444MouseEntered
      float[] hsbvals = new float[3];
      Color.RGBtoHSB(191,219,247,hsbvals);
      tab444.setBackground(Color.getHSBColor(hsbvals[0],hsbvals[1],hsbvals[2]));  
        // TODO add your handling code here:
    }//GEN-LAST:event_tab444MouseEntered

    private void tab444MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab444MouseExited
       float[] hsbvals = new float[3];
      Color.RGBtoHSB(31,122,140,hsbvals);
      tab444.setBackground(Color.getHSBColor(hsbvals[0],hsbvals[1],hsbvals[2]));     
// TODO add your handling code here:
    }//GEN-LAST:event_tab444MouseExited

    private void markBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_markBtnActionPerformed
     saveAttendance();
            // TODO add your handling code here:
    }//GEN-LAST:event_markBtnActionPerformed

    private void tab111MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab111MouseClicked
        dispose(); 
        Teacher newForm = new Teacher();

        // Set the behavior of the new form (e.g., default close operation)
        newForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Display the new form
        newForm.pack();
        newForm.setVisible(true);
    }//GEN-LAST:event_tab111MouseClicked

    private void tab222MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab222MouseClicked
        dispose(); 
        Students newForm = new Students();

        // Set the behavior of the new form (e.g., default close operation)
        newForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Display the new form
        newForm.pack();
        newForm.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_tab222MouseClicked

    private void tab333MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab333MouseClicked
      dispose(); 
        permission newForm = new permission();

        // Set the behavior of the new form (e.g., default close operation)
        newForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Display the new form
        newForm.pack();
        newForm.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_tab333MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
     
    }//GEN-LAST:event_jLabel3MouseClicked

    private void tab444MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tab444MouseClicked
        dispose(); 
        Report newForm = new Report();

        // Set the behavior of the new form (e.g., default close operation)
        newForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Display the new form
        newForm.pack();
        newForm.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_tab444MouseClicked

    private void LogoutBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutBtnMouseClicked
        dispose(); 
        Login newForm = new Login();

        // Set the behavior of the new form 
        newForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Display the new form
        newForm.pack();
        newForm.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_LogoutBtnMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Attendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Attendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Attendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Attendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            private String TeacherID;
            public void run() {
                new Attendance(TeacherID).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LogoutBtn;
    private javax.swing.JTextField TidTxt;
    private javax.swing.JTable attendList;
    private javax.swing.JTextField cidTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JButton markBtn;
    private javax.swing.JPanel tab111;
    private javax.swing.JPanel tab222;
    private javax.swing.JPanel tab333;
    private javax.swing.JPanel tab444;
    // End of variables declaration//GEN-END:variables
}
