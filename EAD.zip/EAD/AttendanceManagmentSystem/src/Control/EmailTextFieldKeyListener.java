/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import javax.swing.JTextField;
/**
 *
 * @author Lihini
 */
public class EmailTextFieldKeyListener extends KeyAdapter {
    private static final int MAX_LENGTH = 50;
    
     @Override
    public void keyTyped(KeyEvent e) {
        JTextField textField = (JTextField) e.getSource();
        String currentText = textField.getText();
        char c = e.getKeyChar();

        // Allow only alphanumeric characters and a single '@', limit length
        if (Character.isLetterOrDigit(c) || (c == '@' && currentText.indexOf('@') == -1) && currentText.length() < 50) {
            // Continue to append characters
        } else {
            e.consume(); // Ignore the key event
        }
    }

}
