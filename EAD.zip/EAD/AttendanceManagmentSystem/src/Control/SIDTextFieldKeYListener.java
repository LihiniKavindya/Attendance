/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import javax.swing.JTextField;

/**
 *
 * @author Lihini
 */
public class SIDTextFieldKeYListener extends KeyAdapter {
    private static final int MAX_DIGITS = 2;
    
      @Override
    public void keyTyped(KeyEvent e) {
        JTextField textField = (JTextField) e.getSource();
        String currentText = textField.getText();
        char c = e.getKeyChar();

        // Allow only digits and limit to 2 digits for both S and T
        if (Character.isDigit(c) && currentText.length() < MAX_DIGITS * 2) {
            // Continue to append digits
        } else if (Character.toUpperCase(c) == 'S' && currentText.length() % 2 == 0) {
            // Allow 'S' only at even positions (0-based index)
            textField.setText(textField.getText() + "S");
            e.consume(); // Ignore the key event
        } 
        else {
            e.consume(); // Ignore the key event
        }}
}